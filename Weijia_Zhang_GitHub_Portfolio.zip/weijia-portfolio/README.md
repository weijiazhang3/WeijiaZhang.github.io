# Weijia Zhang — Personal Research Portfolio

A single-page portfolio ready for GitHub Pages.

## Publish
1. Create a public GitHub repository named `YOUR-USERNAME.github.io` (replace `YOUR-USERNAME` with your exact GitHub username).
2. Upload `index.html` to the repository's root folder and commit it.
3. Go to **Settings → Pages**, choose **Deploy from a branch**, set **main** and **/(root)**, and save.
4. Visit `https://YOUR-USERNAME.github.io` once GitHub Pages deploys.

## Customize
- Edit the text directly in `index.html`.
- Update links to publications or add images of your research with appropriate permissions.
- The site intentionally does not publish your phone number or full CV, which may contain personal details. You can add a public-facing CV later.
- No frameworks, build tools, or external dependencies are required.
